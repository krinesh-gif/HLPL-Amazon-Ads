# Aravi Dashboard — Ads Integration slice

This is the first slice of an in-house replacement for the Nola dashboard: just the
Amazon Ads API connection and a daily pull of Sponsored Products campaigns and
performance into a local database. Nothing else from the full spec yet on purpose —
get this one thing solid, then add the next screen.

## What's here

```
src/
  config/env.ts        loads and validates .env
  amazon-ads/
    auth.ts             Login with Amazon (LWA) OAuth — get/refresh access tokens
    client.ts            shared fetch wrapper (auth headers, error handling)
    profiles.ts           list advertising profiles (accounts/marketplaces)
    campaigns.ts           list Sponsored Products campaigns
    reports.ts               request/poll/download performance reports
  db/
    schema.sql          SQLite tables: profiles, sp_campaigns, sp_campaign_daily_metrics
    client.ts           SQLite connection + schema init
  sync/
    syncProfiles.ts     one-off: list profiles so you can pick AMAZON_ADS_PROFILE_ID
    syncCampaigns.ts    pull current campaign settings
    syncReports.ts      pull daily performance for the last N days
  cli.ts                entry point tying the above together
scripts/
  get-auth-url.ts       step 1 of one-time OAuth setup
  exchange-code.ts      step 2 of one-time OAuth setup
```

No web UI yet — this is deliberately just the pipe. Once campaigns and daily
metrics are landing in SQLite reliably, the next slice is a read screen on top
(this is where the Dashboard tab from the Nola spec would start).

## Getting Amazon Ads API access (do this first — it's the slow part)

This is a manual approval process on Amazon's side, separate from writing any code.
Budget a few days to a couple of weeks for approval; do this in parallel with reading
the code below, not after.

1. **Confirm you have an Amazon Ads (Advertising Console) account** for Aravi Organic —
   you already advertise, so this exists. Note which Amazon login (email) has admin
   access to it; you'll use that same login for the developer steps below.

2. **Register as an Amazon Ads API developer.**
   Go to https://advertising.amazon.com/API/docs/en-us/setting-up/overview and follow
   "Register as a developer." This asks for basic details about what you're building
   (internal analytics/automation dashboard for your own ad account is a normal,
   fine answer) and submits a request for API access. Approval is manual and can take
   time — there's no way to speed this up from our side.

3. **While waiting (or once approved), create a Login with Amazon (LWA) security profile**
   at https://developer.amazon.com/loginwithamazon/console/site/lwa/overview.html.
   This is what gives you `AMAZON_ADS_CLIENT_ID` and `AMAZON_ADS_CLIENT_SECRET`.
   - Under "Web Settings" for the security profile, add an **Allowed Return URL**.
     For local development this should match `AMAZON_ADS_REDIRECT_URI` in `.env`
     (default `http://localhost:3456/callback`). This doesn't need to be a real
     running server yet — you'll just copy the `code` out of the browser's address
     bar after Amazon redirects there.

4. **Once your Ads API access is approved**, copy `.env.example` to `.env` and fill in
   `AMAZON_ADS_CLIENT_ID` and `AMAZON_ADS_CLIENT_SECRET` from the LWA security profile.
   Leave `AMAZON_ADS_REGION=EU` — India's Ads API traffic is served from the EU region
   endpoint regardless of the marketplace being amazon.in.

5. **Run the one-time OAuth consent flow** (this is what `auth.ts` implements):
   ```bash
   npm install
   npm run auth:url
   ```
   Open the printed URL, log in as the Amazon Ads admin user for Aravi, approve access.
   Amazon redirects to your `AMAZON_ADS_REDIRECT_URI` with `?code=...` in the address bar
   — nothing needs to be listening there, just copy the `code` value out of the URL. Then:
   ```bash
   npm run auth:exchange -- <the code>
   ```
   This prints an `AMAZON_ADS_REFRESH_TOKEN` — put it in `.env`. It's long-lived; you
   should not need to repeat steps 5 again under normal use.

6. **Find your profile ID** (which marketplace/account the API calls should target):
   ```bash
   npm run sync:profiles
   ```
   This lists every profile the logged-in user can access. Find the one with
   `country=IN` and put its `profileId` into `.env` as `AMAZON_ADS_PROFILE_ID`.

## Day-to-day use, once set up

```bash
npm run db:init          # create the SQLite file/tables (data/aravi-ads.sqlite)
npm run sync:campaigns    # pull current SP campaign settings
npm run sync:reports      # pull the last 7 days of daily SP campaign performance
npm run sync:reports -- 30   # or a different number of days back
```

Query the results directly with any SQLite tool, e.g.:
```bash
sqlite3 data/aravi-ads.sqlite "select date, campaign_name, cost, sales_14d from sp_campaign_daily_metrics order by date desc limit 20;"
```

## Notes and near-term TODOs

- **Only Sponsored Products is wired up.** Sponsored Brands and Sponsored Display use
  slightly different endpoints/content-types (see the comment in `campaigns.ts`) —
  copy that file's shape for `sbCampaigns.ts` / `sdCampaigns.ts` when you get here.
- **No scheduling yet.** `npm run sync:reports` is manual. Once this is proven reliable,
  wrap it in a cron job / scheduled task (matches the "Daily AMS Fetch" job on Nola's
  Refetch Config screen) rather than building a scheduler from scratch.
- **SQLite is a deliberate starting choice**, not a long-term one — zero setup, one file,
  easy to inspect. Swap `src/db/client.ts` for Postgres once more than one person needs
  to query this or it needs to sit behind a web app.
- **Secrets:** `.env` is gitignored. Never commit real credentials; `.env.example` is the
  only file meant to be checked in.
- **Vendor Central (VC) data** is a separate, harder integration (Amazon doesn't expose
  it through this same Ads API) — deliberately out of scope for this slice.
