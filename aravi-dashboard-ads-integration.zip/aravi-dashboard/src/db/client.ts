import Database from "better-sqlite3";
import { mkdirSync, readFileSync } from "node:fs";
import { dirname } from "node:path";
import { env } from "../config/env.js";

mkdirSync(dirname(env.dbPath), { recursive: true });

export const db = new Database(env.dbPath);
db.pragma("journal_mode = WAL");

export function initSchema(): void {
  const schema = readFileSync(new URL("./schema.sql", import.meta.url), "utf-8");
  db.exec(schema);
}
