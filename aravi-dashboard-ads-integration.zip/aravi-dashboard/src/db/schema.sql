-- Minimal schema for the Ads-integration slice. Deliberately small:
-- add tables as new sync jobs (ad groups, keywords, SB/SD) come online,
-- rather than modeling everything up front.

CREATE TABLE IF NOT EXISTS profiles (
  profile_id     TEXT PRIMARY KEY,
  country_code   TEXT NOT NULL,
  currency_code  TEXT NOT NULL,
  account_name   TEXT,
  account_type   TEXT,
  synced_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sp_campaigns (
  campaign_id    TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  state          TEXT NOT NULL,
  targeting_type TEXT NOT NULL,
  daily_budget   REAL NOT NULL,
  start_date     TEXT,
  end_date       TEXT,
  synced_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sp_campaign_daily_metrics (
  date           TEXT NOT NULL,
  campaign_id    TEXT NOT NULL,
  campaign_name  TEXT,
  impressions    INTEGER NOT NULL DEFAULT 0,
  clicks         INTEGER NOT NULL DEFAULT 0,
  cost           REAL NOT NULL DEFAULT 0,
  sales_14d      REAL NOT NULL DEFAULT 0,
  purchases_14d  INTEGER NOT NULL DEFAULT 0,
  synced_at      TEXT NOT NULL,
  PRIMARY KEY (date, campaign_id)
);
